package Ejercicio;

import java.util.ArrayList;

public class gestorPeliculas {
	
	private static ArrayList<Peliculas> listaPeliculas = new ArrayList<>();
	private static int idActual = 1;
	
	public static int getIdActual() {
	    return idActual;
	}

}


