package entidades;

public class EstadoPrestamo{
	public static final int PENDIENTE = 1;
    public static final int APROBADO = 2;
    public static final int RECHAZADO = 3;
}
