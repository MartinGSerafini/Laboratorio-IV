package entidades;

public class EstadoCuota {
	public static final int PENDIENTE = 1;
    public static final int PAGADO = 2;
}
