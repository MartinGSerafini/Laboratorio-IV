package excepciones;

public class OperacionNoEfectuadaExc extends Exception{
	public OperacionNoEfectuadaExc(String mensaje) {
		super(mensaje);
	}
}